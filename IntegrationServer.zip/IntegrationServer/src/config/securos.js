
module.exports = {
    
    ip:'localhost',
    port:3002,
    path:'/api/securos/event',
}
