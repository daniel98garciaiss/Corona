
module.exports = {
    
        // ip:'localhost',
        // port:8182,
        path:'/api/OPC/Read',
        pathWrite:'/api/OPC/write',
}

